﻿namespace IncidentReportingSystem.API.Options;

public sealed class MyAppSettings
{
    public double SampleRatio { get; set; } = 1.0;
    public string? OtherSetting { get; set; }
}
